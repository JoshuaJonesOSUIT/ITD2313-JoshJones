x = int(input("Enter the first side of the triangle: "))
y = int(input("Enter the second side of the triangle: "))
z = int(input("Enter the third side of the triangle: "))
if x == y and y == z:
    print("The triangle is equilateral.")
else:
    print("The triangle is not equilateral.")
