theSum = 0.0
count = 0
while True:
    data = input("Enter a number of just enter to quit: ")
    if data == "":
        break
    number = float(data)
    theSum += number
    count += 1
print("The sum is", theSum)
if count > 0:
    average = theSum / count
    print("The average is", average)
else:
    print("Average: undefined because the terms enetered are 0")
