first = int(input("Enter the first side of the triangle: "))
second = int(input("Enter the second side of the triangle: "))
third = int(input("Enter the third side of the triangle: "))
if first == second + third:
    print("The triangle is a right triangle")
elif second == first + third:
    print("The triangle is a right triangle")
elif third == first + second:
    print("The triangle is a right triangle")
else:
    print("The triangle is not a right triangle")
