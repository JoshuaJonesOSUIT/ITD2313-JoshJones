Python 3.8.5 (tags/v3.8.5:580fbb0, Jul 20 2020, 15:57:54) [MSC v.1924 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> print(' Josh Jones, 21885 E. Dawes Cm. Rd., 918-804-2032')
 Josh Jones, 21885 E. Dawes Cm. Rd., 918-804-2032
>>> 