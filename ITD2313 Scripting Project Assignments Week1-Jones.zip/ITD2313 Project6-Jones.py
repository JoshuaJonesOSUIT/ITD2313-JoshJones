radius = float(input("Enter with radius: "))
area = 3.14 * radius ** 2
print("The are is", area, "sqaure units.")
