length = int(input("Enter with length: "))
width = int(input("Enter with width: "))
area = length * width
print("The are is", area, "sqaure units.")
