numiterations = int(input("Enter the number of iterations: "))
pi_value = 0
counter = 1

for i in range(1, numiterations + 1):
    if (i % 2 != 0):
        pi_value += 1/counter

    else:
        pi_value -= 1/counter

    counter += 2

pi_value *= 4
print("The approximation of pi is ", pi_value)
