initialheight = int(input("Enter the inital height of the ball: "))
bouncinessindex = float(input("Enter the bounce index of the ball: "))
bouncing = int(input("Enter how many times the ball can bounce: "))

distance = 0

while bouncing > 0:
    distance = distance + initialheight
    initialheight = initialheight * bouncinessindex
    distance = distance + initialheight
    bouncing-= 1
    print("Total distance traveled is", distance, "feet.")
