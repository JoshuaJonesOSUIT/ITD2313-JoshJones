import math
def prediction():
    organisms = int(input("Enter the initisal number of organisms: "))
    growth = int(input("Enter the rate of growth that is greater than zero: "))
    numhours = int(input("Enter the number of hours to achieve this rate: "))
    totalhours = int(input("Enter the total hours of growth: "))

    totalorganisms = organisms
    hours = 1
    while hours < totalhours:
        totalorganisms *= growth
        hours += numhours
        print("The total population is " + str(int(totalorganisms)))

prediction()
