edge = float(input("Enter with edge: "))
surfacearea = 6 * (edge * edge)
print("The surface area is", surfacearea)
