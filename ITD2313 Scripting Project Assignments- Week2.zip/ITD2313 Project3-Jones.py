nv = float(input("Enter the number of new videos: "))
ov = float(input("Enter the number of old videos: "))
total = (nv * 3.00) + (ov * 2.00)
print("The total cost for your videos is",total, "dollars")
