mass = float(input("Enter mass in kilograms: "))
velocity = float(input("Enter velocity in m/s: "))
momentum = mass * velocity
print("The momentum of this object is", momentum)
