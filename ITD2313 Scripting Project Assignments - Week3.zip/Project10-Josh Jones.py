HW=int(input("Enter your hourly wage:"))
RH=int(input("Enter your total regular hours worked:"))
Overtime=int(input("Enter your total overtime hours worked:"))
OT = 1.5
Regularpay = HW*RH
Overtimepay = Overtime*OT
Totalpay = Regularpay + Overtimepay
print("Your total weekly pay is", Totalpay, "dollars")
