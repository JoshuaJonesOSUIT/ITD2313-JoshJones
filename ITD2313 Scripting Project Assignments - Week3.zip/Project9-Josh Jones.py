Kilo=int(input("Enter the amount of kilometers:"))
DPM = 90*60
oneKilo = DPM/10000
NM = oneKilo*Kilo
print(Kilo, "is", NM, "Nautical miles")
